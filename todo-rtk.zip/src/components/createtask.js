import React, { useState } from "react";
import Modalpopup from "./modal";
import MyCard from "./card";
import { useSelector } from 'react-redux';

const CreateToDolist = () => {
  const [modal, setmodal] = useState(false);
  const todoItems = useSelector((state) => state.todo);

  const toggle = () => setmodal(!modal);

  const saveTask = () => {
    setmodal(false);
  }

  return (
    <>
      <div className="header text-center">
        <h3>ToDo List</h3>
        <button className="btn btn-primary" onClick={toggle}>Create Task</button>
      </div>
      <div className="task-container">
        {todoItems.length > 0 ? (
          todoItems.map((obj, index) => (
            <MyCard key={index} taskobj={obj} index={index} />
          ))
        ) : (
          <p>No tasks to display.</p>
        )}
      </div>
      <Modalpopup modal={modal} toggle={toggle} saveTask={saveTask} />
    </>
  );
}

export default CreateToDolist;
