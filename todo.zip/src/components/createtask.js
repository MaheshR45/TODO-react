import React, { useEffect, useState } from "react";
import Modalpopup from "./modal";
import MyCard from "./card";

const CreateToDolist = () => {
  const [modal, setmodal] = useState(false);
  const [taskList, settaskList] = useState([]);

  useEffect(() => {
    let arr = localStorage.getItem("taskList");
    if (arr) {
      let obj = JSON.parse(arr);
      settaskList(obj);
    }
  }, []); // Add an empty dependency array to ensure this effect runs only once

  const toggle = () => setmodal(!modal);

  const saveTask = (taskobj) => {
    // Make a copy of the existing taskList
    let tempList = [...taskList];
    tempList.push(taskobj);

    // Save the updated list to localStorage
    localStorage.setItem("taskList", JSON.stringify(tempList));
    
    // Update the state with the new list
    settaskList(tempList);

    setmodal(false);
  }

  const deleteTask = (index) => {
    // Make a copy of the existing taskList
    let tempList = [...taskList];
    tempList.splice(index, 1);

    // Save the updated list to localStorage
    localStorage.setItem("taskList", JSON.stringify(tempList));

    // Update the state with the new list
    settaskList(tempList);
  }
 const updateListArray=(obj,index)=>{
    let templist=taskList;
    templist[index]=obj
    localStorage.setItem("taskList",JSON.stringify(templist))
    settaskList(templist)
    window.location.reload();
 }
  return (
    <>
      <div className="header text-center">
        <h3>ToDo List</h3>
        <button className="btn btn-primary" onClick={() => setmodal(true)}>Create Task</button>
      </div>
      <div className="task-container">
        {taskList.map((obj, index) => <MyCard taskobj={obj} index={index} deleteTask={deleteTask} updateListArray={updateListArray} />)}
      </div>
      <Modalpopup modal={modal} toggle={toggle} saveTask={saveTask} />
    </>
  );
}

export default  CreateToDolist 

