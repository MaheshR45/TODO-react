import logo from './logo.svg';
// bootstrap,reactstrap,obj use,refresh local storage,,card top border color
import './App.css';
import TodoList from './components/createtask';
import 'bootstrap/dist/css/bootstrap.min.css'

function App() {
  return (
    <div className="App">
      <TodoList />
    </div>
  );
}

export default App;
